package GYM_Project;

/**
 *
 * @author Ouda
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        login Us = new login();
        Us.setVisible(true);
    }
    
}
